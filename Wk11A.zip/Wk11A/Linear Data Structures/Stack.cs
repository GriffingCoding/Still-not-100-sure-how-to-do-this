﻿using System.Collections.Generic;
using System.Collections;

namespace Linear_Data_Structures
{
    public class Stack
    {
        Stack<int> stack = new Stack<int>();
    }

}
