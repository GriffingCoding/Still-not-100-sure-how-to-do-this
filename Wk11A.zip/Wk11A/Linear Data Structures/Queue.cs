﻿using System;
using System.Collections.Generic;
using System.Collections;


namespace Linear_Data_Structures
{
    public class Queue<T>
    {
        Queue<int> queue = new Queue<int>();
    }
}
